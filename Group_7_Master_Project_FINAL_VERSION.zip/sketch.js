//asset variables
let Farm; //variable to hold farm image
let Logo; //variable to hold logo image
let yay; //variable to hold yay sound effect
let buzzer; //variable to hold buzzer sound effect
let ding; //variable to hold ding sound effect

//backend global variables
let winTrigger = false; //toggles when score counter reaches max score
var screen = 2; //sets the screen that appears when play button is pressed
/* screen values

screen 0 = start screen
screen 1 = sound touch game
screen 2 = typing game
screen 3 = shape matching game
screen 4 = sound touch game instructions
screen 5 = typing game instructions
screen 6 = shape matching game instructions

*/

//timer global variables
let timerStart = false; //toggles the timer to start(true) or stop(false)
let millisecs = 0;
let seconds = 0;
let minutes = 0;

//soundTouchGame global variables
let playMode = "restart"; //makes it so the sound in the draw() function doesn't play over itself
let animalImageArray = []; //array to hold the images in the big box
let animalSoundArray = []; //array to hold the sounds in the same order as the animals in the big box
let arraySize = 10; //num of elements in sound touch arrays
let smallBoxArray = []; //array for images in the 2x5 row of animals for user to click on
let smallSoundArray = []; //array for noises in the 2x5 row of animals for user to click on

let index = 0; //global variable to keep track of what animal is in the big ST box
let STCounter = 0; //Initializing the soundtouch counter to 0

//Typing game global variables
let newArr = []; //array that stores the words the user has to type
let TGIndex; //tracks the word being shown in the gray box
let TCounter = 0; //Counter variable, goes up to 5
let myInput; //input box for user to type in
let enterButton; //enter button for user to submit their word (pressing the enter key also works)
let newWordButton; //button that increments TGIndex to give user a new word

//Shape matching game global variables
let SMCounter = 0; //counter for shapes placed correctly
let wrkWidth = 1500; //replaces the width function
let wrkHeight = 850; //replaces the height function

let circ1X; //moving Circle X value
let circ1Y; //moving Circle Y value
let circ2X; //stationary circle X value
let circ2Y; //stationary circle Y value
let circR = 75; //Circle radius
let circD = circR * 2; //Circle Diameter

let rect1X; //moving rect X value
let rect1Y; //moving rect Y value
let rect2X; //stationary rect X value
let rect2Y; //stationary rect Y value
let rectWidth = 300; //rect Width value
let rectHeight = 100; //rect Height value

let sq1X; //moving square X value
let sq1Y; //moving square Y value
let sq2X; //stationary square X value
let sq2Y; //stationary square Y value
let sqD = 150; //square Dimensions value

let circGrabbed = false; //toggles if user grabs circle
let rectGrabbed = false; //toggles if user grabs rectangle
let sqGrabbed = false; //toggles if user grabs square

let winCheck1; //toggles if circle in correct position
let winCheck2; //toggles if rectangle in correct position
let winCheck3; //toggles if square in correct position
let startTrigger = false; //toggles start button (disappear and start clock)

function preload() {
  Farm = loadImage("assets/Farm.jpg");
  Logo = loadImage("assets/Logo.png");

  //animal images
  animalImageArray[0] = loadImage("assets/animal_images/duck.png");
  animalImageArray[1] = loadImage("assets/animal_images/rooster.png");
  animalImageArray[2] = loadImage("assets/animal_images/cat.png");
  animalImageArray[3] = loadImage("assets/animal_images/pig.png");
  animalImageArray[4] = loadImage("assets/animal_images/goat.png");
  animalImageArray[5] = loadImage("assets/animal_images/cow.png");
  animalImageArray[6] = loadImage("assets/animal_images/dog.png");
  animalImageArray[7] = loadImage("assets/animal_images/sheep.png");
  animalImageArray[8] = loadImage("assets/animal_images/donkey.png");
  animalImageArray[9] = loadImage("assets/animal_images/horse.png");

  //animal sounds
  animalSoundArray[0] = loadSound("assets/animal_sounds/Duck.mp3");
  animalSoundArray[1] = loadSound("assets/animal_sounds/Rooster.mp3");
  animalSoundArray[2] = loadSound("assets/animal_sounds/Cat.mp3");
  animalSoundArray[3] = loadSound("assets/animal_sounds/Pig.mp3");
  animalSoundArray[4] = loadSound("assets/animal_sounds/Goat.mp3");
  animalSoundArray[5] = loadSound("assets/animal_sounds/Cow.mp3");
  animalSoundArray[6] = loadSound("assets/animal_sounds/Dog.mp3");
  animalSoundArray[7] = loadSound("assets/animal_sounds/Sheep.mp3");
  animalSoundArray[8] = loadSound("assets/animal_sounds/Donkey.mp3");
  animalSoundArray[9] = loadSound("assets/animal_sounds/Horse.mp3");

  //sound effects
  yay = loadSound("assets/sfx/yay.mp3");
  ding = loadSound("assets/sfx/Ding.mp3");
  buzzer = loadSound("assets/sfx/buzzer.mp3");
}

function setup() {
  createCanvas(1600, 1080);
  textFont("Verdana");
  soundFormats("mp3");

  //for Sound Touch Game
  initializeSmallArrays(); //sets the arrays for small animal box equal to the arrays for the animal big animal box
  fisherYatesShuffle(smallBoxArray, smallSoundArray); //Randomizes the arrays for the small boxes

  //for Typing game
  typingGameSetup();

  //for Shape Matching game
  initializeShapes();
}

function draw() {
  background(25, 184, 22);

  if (screen == 0) {
    startScreen(); //sends user to home screen
  } else if (screen == 1) {
    soundTouchGame(); //sends user to sound touch game
  } else if (screen == 2) {
    typingGame(); //sends user to typing game
  } else if (screen == 3) {
    shapeMatchingGame(); //sends user to shape matching game
  } else if (screen == 4) {
    gameInstructions(); //Sound Touch game instructions
  } else if (screen == 5) {
    gameInstructions(); //Typing game instructions
  } else if (screen == 6) {
    gameInstructions(); //Shape Matching game instructions
  }

  //hides some DOM elements for game 2
  if (screen != 2) {
    //hides the DOM elements for game 2 when screen 2 is not being displayed
    enterButton.hide();
    newWordButton.hide();
    myInput.hide();
  } else if (winTrigger == true && screen == 2) {
    //hides the DOM elements when the youWin menu pops up
    enterButton.hide();
    newWordButton.hide();
    myInput.hide();
  } else {
    //shows the DOM elements for game 2 when screen 2 is being displayed
    enterButton.show();
    newWordButton.show();
    myInput.show();
  }
}

function startScreen() {
  image(Farm, 0, 0, 1600, 1080);
  image(Logo, 250, 200);
  startScreenBoxes(); //creates the boxes that say "Game#[i]" and "instructions"
}

//used in startScreen
function startScreenBoxes() {
  //box position values
  let x = 250;
  let y = 725;
  let width = 275;
  let length = 150;
  fill(161, 120, 6);

  //game# boxes
  for (let i = 0; i < 3; i++) {
    rect(x, y, width, length);
    x += 400;
  }

  //instruction boxes
  x = 250;
  for (let i = 0; i < 3; i++) {
    rect(x + 20, y + 175, width - 50, length - 27);
    x += 400;
  }

  //text position values
  let x2 = 255;
  let y2 = y + 100;

  fill(0);
  textSize(55);
  for (let i = 1; i < 4; i++) {
    text("GAME #" + i, x2, y2);
    x2 += 400;
  }

  textSize(35);
  x2 = 255;
  for (let i = 1; i < 4; i++) {
    text("Instructions", x2 + 20, y2 + 150);
    x2 += 400;
  }
}

//box that lets the user return to start screen in all 3 games
function homeBox() {
  fill(250, 231, 132);
  strokeWeight(2);
  rect(50, 50, 200, 100);
  strokeWeight(1);

  fill(255, 0, 0);
  textSize(65);
  stroke(0);
  text("Home", 53, 123);
}

//box that takes the user to the instruction menu from the game menu
function instructionBox() {
  fill(250, 231, 132);
  strokeWeight(2);
  rect(280, 50, 200, 100);
  strokeWeight(1);

  fill(255, 0, 0);
  textSize(65);
  stroke(0);
  textSize(30);
  text("Instructions", 290, 115);
}

//displays the instructions in the instructions screens
function gameInstructions() {
  homeBox(); //box that allows to user to return to the start screen

  secondGameBoxes(); //box that allows the user to go to the game from the instructions screen

  fill(0);
  textAlign(CENTER);
  let instructions = "";

  if (screen == 4) {
    textSize(90);
    text("Sound Touch Game", 800, 200);
    //Sound touch game instructions
    instructions =
      "\nListen to the sound that is played and click\non the animal making the sound\nto earn a point.\n\nClick on the big box to hear the sound again\n\nYou win the game once you have 10 points!";
  }

  if (screen == 5) {
    textSize(90);
    text("Typing Game", 800, 200);
    //typing game instructions
    instructions =
      "Type the exact word shown into the blank box. \n\nIf you mistype the word a new word \nwill be given to type out. \n\nEach word counts for 1 point and you \nonly need 5 correct words to win!\n\nClick the new word box for a new word.";
  }

  if (screen == 6) {
    textSize(90);
    text("Shape Matching Game", 800, 200);
    //shape matching game instructions
    instructions =
      "Drag the colored shape into the larger \nshape as fast as you can. \n\nA timer will keep track of how fast you are. \n\nAs soon as all shapes have been matched \nyou win the game, \nbut keep playing to see how \nfast you can match the shapes!";
  }

  textSize(60);
  text(instructions, 800, 350);
  textAlign(LEFT);
}

//box that sends the user into the game from the instructions screen
function secondGameBoxes() {
  fill(250, 231, 132);
  strokeWeight(2);
  rect(50, 170, 200, 100);
  strokeWeight(1);

  fill(255, 0, 0);
  textSize(65);
  stroke(0);
  textSize(40);
  let x = 55;
  let y = 235;

  if (screen == 4) {
    text("Game #1", x, y);
  }
  if (screen == 5) {
    text("Game #2", x, y);
  }
  if (screen == 6) {
    text("Game #3", x, y);
  }
}

//counter function for games
//counter param takes which counter is needed for the game
//magicNum param takes what number is needed for max score
function newCounter(counter, magicNum) {
  let x = 1140;
  let x2 = x + 250;

  //score counter background
  strokeWeight(2);
  fill(250, 231, 132);
  rect(x, 50, 400, 100); //box for the score counter
  strokeWeight(1);

  //"score counter" text
  fill(255, 0, 0);
  textSize(37);
  stroke(0);
  textAlign(CENTER);
  text("SCORE\nCOUNTER", x + 100, 90);
  textAlign(LEFT);

  //colon text
  textSize(100);
  text(":", x + 185, 128);

  textSize(37);
  //Displays the number of total points
  //disappears after reaching magicNum to emphasize magicNum
  if (magicNum == 10) {
    if (counter < magicNum) {
      text("/" + magicNum, x + 330, 140);
    }
  } else if (magicNum == 3 || magicNum == 5) {
    if (counter < magicNum) {
      text("/" + magicNum, x + 340, 140);
    }
  }

  textSize(120);
  //shows the actual score counter
  if (counter >= magicNum) {
    x2 -= 15; //centers the counter text
    counter = magicNum; //prevents STCounter from incrementing past magicNum
  }
  text(counter, x2, 143);

  if (counter >= magicNum) {
    winTrigger = true;
    youWin();
  } else {
    winTrigger = false; //takes the youWin() display away
  }
}

//screen that lets the user go home or reset the game when they win
function youWin() {
  if (winTrigger == true) {
    fill(100);
    strokeWeight(7);
    rect(4, 300, 1592, 600);

    //displays the graphic
    fill(235, 202, 28);
    textSize(340);
    textAlign(CENTER);
    text("YOU WIN", 800, 600);
    textAlign(LEFT);

    //values for the home and reset boxes
    let x = 380;
    let y = 680;
    let width = 350;
    let height = 175;
    strokeWeight(5);

    fill(250, 231, 132);
    rect(x, y, width, height); //home box
    rect(x + 500, y, width, height); //reset box

    strokeWeight(1);

    fill(0);
    textSize(100);
    text("Home", x + 25, y + 125);
    text("Reset", x + 530, y + 125);

    if (screen == 3) {
      timerStart = false; //pauses timer
      //takes away users ability to keep holding shapes
      circGrabbed = false;
      rectGrabbed = false;
      sqGrabbed = false;
    }
  }
}

//used in all 3 games
function resetGame() {
  if (screen == 1) {
    STCounter = 0;
    index = 0; //resets the array in the big box
    fisherYatesShuffle(smallBoxArray, smallSoundArray); //randomizes the small boxes again
  }

  if (screen == 2) {
    TCounter = 0;
  }

  if (screen == 3) {
    SMCounter = 0;
    initializeShapes(); //randomizes shape locations
    millisecs = 0;
    seconds = 0;
    minutes = 0;
    winCheck1 = false;
    winCheck2 = false;
    winCheck3 = false;
    startTrigger = false;
  }
}

//timer for Shape matching game
function timer(x, y) {
  if (timerStart == true) {
    if (int(millis() / 100) % 10 != millisecs) {
      //increment milliseconds
      millisecs++;
    }

    if (millisecs >= 10) {
      //increment seconds
      millisecs -= 10;
      seconds++;
    }

    if (seconds >= 60) {
      //increment minutes
      seconds -= 60;
      minutes++;
    }
  }

  textSize(54);
  text(nf(minutes, 2) + ":" + nf(seconds, 2) + ":" + nf(millisecs, 1), x, y);
}

//Game 1 / Screen 1
function soundTouchGame() {
  homeBox(); //creates home box in top left corner
  instructionBox(); //creates instruction box in top left corner
  createSTBoxes(); //creates boxes used in game
  displayAnimals(); //displays animals in boxes
  newCounter(STCounter, 10); //creates counter
}

//creates the boxes needed for the sound touch game
function createSTBoxes() {
  let x = 200;
  let y = 600;
  let size = 150;
  fill(250, 231, 132);

  //big box at top
  rect(400, 200, 750, 300);

  //creates the two rows of boxes
  for (let u = 0; u < 2; u++) {
    for (let i = 0; i < 5; i++) {
      rect(x, y, size, size);
      x += 250;
    }

    x = 200;
    y += 250;
  }
}

//sets the smallBoxArray and smallSoundArray equal to their animalImage/SoundArray counterparts
function initializeSmallArrays() {
  for (let i = 0; i < arraySize; i++) {
    smallBoxArray[i] = animalImageArray[i];
    smallSoundArray[i] = animalSoundArray[i];
  }
}

//used to shuffle the smallBoxArray and smallSoundArray
function fisherYatesShuffle(array, array2) {
  var m = arraySize,
    t,
    i;

  // While there remain elements to shuffle…
  while (m) {
    // Pick a remaining element…
    i = Math.floor(Math.random() * m--);

    // And swap it with the current element.
    t = array[m];
    array[m] = array[i];
    array[i] = t;

    t = array2[m];
    array2[m] = array2[i];
    array2[i] = t;
  }

  return array;
}

//displays the animals in the boxes
function displayAnimals() {
  let x = 207;
  let y = 605;
  let size = 140;

  //big animal image in top box
  image(animalImageArray[index], 600, 200, 300, 300);

  //dislpays 2 randomized rows of animals
  let newIndex = 0;

  for (let u = 0; u < 2; u++) {
    for (let i = 0; i < 5; i++) {
      image(smallBoxArray[newIndex], x, y, size, size);

      x += 250;
      newIndex++;
    }

    x = 200;
    y += 250;
  }
}

//loops the arrays for the big box
function resetSTArray() {
  //makes the animal arrays loop so they can't break
  if (index >= arraySize) {
    index = 0;
  }
}

//functionality for soundTouch boxes
function STBox(smallX, arrayNum) {
  if (mouseX < smallX + 150 && mouseX > smallX) {
    if (animalImageArray[index] == smallBoxArray[arrayNum]) {
      index++; //changes animal in big box
      resetSTArray(); //loops the animalImageArray and animalSoundArray
      STCounter++; //increments the counter
      animalSoundArray[index].play(); //plays sound of next animal in animalImageArray
    } else {
      smallSoundArray[arrayNum].play(); //plays sound of animal on box if user selects wrong animal
    }
  }
}

//Game 2 / Screen 2
//this gets called in draw
function typingGame() {
  homeBox(); //creates home box in top left corner
  instructionBox(); //creates instruction box in top left corner
  createTGBoxes(); //creates boxes used in game
  newCounter(TCounter, 5); //creates counter
}

//this is all the stuff that gets called in the setup function
function typingGameSetup() {
  makeInput(); //creates the input field
  makeEnterButton(); //creates the enter button
  makeNewWordButton(); //creates the new word button
  let wordList = [    "Field",
    "Hay", "Garden", "Ranch", "Soil",    "Dog",    "Horse",    "Pig",    "Cat",    "Sheep",
    "Goat",    "Cow",     "Rooster",     "Pasture",     "Tractor",
    "Vineyard",     "Range",     "Donkey",     "Shovel",    "Rabbit",
  ];
  newArr = shuffle(wordList); //shuffles the array when the game starts
  TGIndex = 0;
}

//used to make sure input is working
function myInputEvent() {
  console.log("you are typing: ", this.value());
}

//creates the input box used for the game
function makeInput() {
  let col = color(250, 231, 132);

  myInput = createInput("");
  myInput.position(400, 550);
  myInput.size(795, 145);
  myInput.style("font-size", "50px"); //changes the font size
  myInput.style("background-color", col); //changes the background color

  myInput.input(myInputEvent);
}

//creates enter button
function makeEnterButton() {
  let col = color(250, 231, 132);

  enterButton = createButton("Enter");
  enterButton.position(461, 785);
  enterButton.size(277, 130);
  enterButton.style("font-size", "65px"); //changes the font size
  enterButton.style("background-color", col); //changes the background color
  enterButton.mousePressed(doSomething);
}

//creates new word button
function makeNewWordButton() {
  let col = color(250, 231, 132);

  newWordButton = createButton("New\nWord");
  newWordButton.position(861, 785);
  newWordButton.size(277, 130);
  newWordButton.style("font-size", "58px"); //changes the font size
  newWordButton.style("background-color", col); //changes the background color
  newWordButton.mousePressed(newWord);
}

//lets user incrememnt the index if current word is too difficult
function newWord() {
  TGIndex++; //grabs new word from index
  resetTypingArray(); //resets index back to 0 if user presses button too many times
}

//increments the array if word is correct, displays error message if incorrect
function doSomething() {
  let myText = myInput.value();

  if (myText == newArr[TGIndex]) {
    //if user types correct word
    TGIndex++; //increments the array index to show next word
    resetTypingArray(); //checks to see if array needs to be looped
    console.log(newArr[TGIndex]); //used to make sure game is working
    TCounter++; //increments counter
    ding.play(); //plays ding noise to let user know they got it correct
  } else {
    //if user types word incorrectly
    console.log(myText, newArr[TGIndex]); //used to make sure game is working
    alert("Incorrect"); //alerts user if they typed the word incorrectly
    TGIndex++;                                //increments the array index to show next word
    buzzer.play();                          //sound is broken, so it's commented out
  }
}

//sets index to 0 to prevent game from breaking
function resetTypingArray() {
  if (TGIndex >= 20) {
    TGIndex = 0;
  }
}

//used in typingGame
function createTGBoxes() {
  let width = 150;
  textAlign(CENTER);

  //box for the word given to user
  fill(181, 186, 198);
  rect(300, 325, 1000, width);

  fill(250, 231, 132);
  rect(862, 787, 275, width - 25); //box that displays new word
  rect(462, 787, 275, width - 25); //box that displays enter

  fill(0);
  textSize(70);
  text("ENTER", 600, 875);
  textSize(50);
  text("New\nWord", 1000, 835);

  textSize(100);
  fill(0);
  //displays current word in the array
  text(newArr[TGIndex], 800, 435);
  textAlign(LEFT);
}

//Game 3 / Screen 3
function shapeMatchingGame() {
  homeBox(); //creates home box in top left corner
  instructionBox(); //creates instruction box in top left corner
  workspaceBox(); //creates the gray box that the shapes are in
  workspace(); //draws all the shapes and lets them move
  newCounter(SMCounter, 3); //creates counter
  startBox(); //start box user has to click to start the game

  //temporary timer stop button
  /*
  fill(255, 0, 0);
  rect(500, 50, 100, 100);
  fill(0);
  textSize(42);
  text("STOP", 500, 125);
  */
}

//creates the big gray box the shapes can move around in
function workspaceBox() {
  strokeWeight(2);
  fill(210);
  rectMode(CORNER);
  rect(50, 180, wrkWidth, wrkHeight);
  strokeWeight(1);
  //spawnAreas();    //uncomment to see spawn areas for circle and square
  rectMode(CENTER);
}

//where the shapes appear and function
function workspace() {
  fill(0);
  textAlign(CENTER);
  timer(800, 120);
  textAlign(LEFT);

  strokeWeight(2);
  rectMode(CENTER);
  stroke(0);
  fill(255);

  //calculates the distance between the colored shapes and the stationary shapes
  let cd = dist(circ1X, circ1Y, circ2X, circ2Y);
  let rd = dist(rect1X, rect1Y, rect2X, rect2Y);
  let sd = dist(sq1X, sq1Y, sq2X, sq2Y);

  //CIRCLE WORKSPACE
  //checks if moving circle is inside stationary circle
  if (cd < circR - (circR - 10)) {
    stroke(0, 255, 0);
    fill(165, 255, 165); //if it's fully inside it will turn green
    winCheck1 = true; //if shape is green it will increment the counter
    winCheck(); //checks if counter is at 3
  } else if (cd < circR + (circR + 10)) {
    stroke(255, 0, 0);
    fill(255, 164, 165); //if only partially inside it'll turn red
    winCheck1 = false; //if shape is red it will decrement the counter if it needs to
    winCheck(); //checks if counter is at 3
  }
  circle(circ2X, circ2Y, circD + 20); //big stationary circle

  stroke(0);
  fill(165, 150, 250);
  circle(circ1X, circ1Y, circD); //moving circle

  //RECTANGLE WORKSPACE
  //checks if moving rectangle is inside stationary rectangle
  fill(255);
  if (rd < rectWidth - (rectWidth - 10)) {
    stroke(0, 255, 0);
    fill(165, 255, 165); //if it's fully inside it will turn green
    winCheck2 = true; //if shape is green it will increment the counter
    winCheck(); //checks if counter is at 3
  } else if (rd < rectWidth - 200) {
    stroke(255, 0, 0);
    fill(255, 164, 165); //if only partially inside it'll turn red
    winCheck2 = false; //if shape is red it will decrement the counter if it needs to
    winCheck(); //checks if counter is at 3
  }
  rect(rect2X, rect2Y, rectWidth + 10, rectHeight + 10); //big stationary rectangle

  stroke(0);
  fill(255, 0, 255);
  rect(rect1X, rect1Y, rectWidth, rectHeight); //moving rectangle

  //SQUARE WORKSPACE
  //checks if moving square is inside stationary square
  fill(255);
  if (sd < sqD - (sqD - 10)) {
    stroke(0, 255, 0);
    fill(165, 255, 165); //if it's fully inside it will turn green
    winCheck3 = true; //if shape is green it will increment the counter
    winCheck(); //checks if counter is at 3
  } else if (sd < sqD + 5) {
    stroke(255, 0, 0);
    fill(255, 164, 165); //if it's fully inside it will turn red
    winCheck3 = false; //if shape is red it will decrement the counter if it needs to
    winCheck(); //checks if counter is at 3
  }
  rect(sq2X, sq2Y, sqD + 10, sqD + 10);

  stroke(0);
  fill(100, 220, 180);
  rect(sq1X, sq1Y, sqD, sqD);

  //LEAVE AT BOTTOM
  rectMode(CORNER);
  strokeWeight(1);
}

//sets the postition the shapes will spawn in
function initializeShapes() {
  circ1X = random(900, 1470);
  circ1Y = random(730, 910);
  circ2X = random(170, 630);
  circ2Y = random(270, 470);

  sq1X = random(900, 1470);
  sq1Y = random(270, 470);
  sq2X = random(170, 320);
  sq2Y = random(730, 910);

  rect1X = random(200, 570);
  rect1Y = random(530, 880);
  rect2X = random(820, 1420);
  rect2Y = random(270, 670);
}

//shows the spots the circles and squares can spawn
function spawnAreas() {
  //spawn area for moving square
  fill(180, 100, 255);
  rect(830, 190, 700, 370);

  //spawn area for stationary square
  fill(165, 255, 165);
  rect(60, 650, 350, 370); //650

  fill(0);
  rect(380, 680, 350, 175);

  fill(255);
  text("HOME BOX", 500, 750);

  //spawn area for moving circle
  fill(0, 255, 150);
  rect(830, 650, 700, 370);

  //spawn area for stationary circle
  fill(255, 164, 165);
  rect(60, 190, 650, 370);
}

//checks to see if all the shapes are aligned correctly
function winCheck() {
  if (screen == 3) {
    let num1 = 0;
    let num2 = 0;
    let num3 = 0;
    let totalNumber = 0;

    if (winCheck1 == true) {
      num1 = 1;
      //console.log("num1: " + num1);
    } else if (winCheck1 == false) {
      num1 = 0;
      //console.log("num1: " + num1);
    }

    if (winCheck2 == true) {
      num2 = 1;
      //console.log("num2: " + num2);
    } else if (winCheck2 == false) {
      num2 = 0;
      //console.log("num2: " + num2);
    }

    if (winCheck3 == true) {
      num3 = 1;
      //console.log("num3: " + num3);
    } else if (winCheck3 == false) {
      num3 = 0;
      //console.log("num3: " + num3);
    }

    totalNumber = num1 + num2 + num3;
    //console.log("totalNumber: " + totalNumber);

    SMCounter = totalNumber;
  }
}

//box to start the game
function startBox() {
  if (startTrigger == false) {
    fill(161, 120, 6);
    rect(50, 180, wrkWidth, wrkHeight);

    rectMode(CENTER);
    fill(250, 231, 132);
    strokeWeight(2);
    rect(800, 520, 350, 150);
    strokeWeight(1);

    fill(255, 0, 0);
    textSize(105);
    stroke(0);
    textAlign(CENTER);
    text("START", 800, 560);
    textAlign(LEFT);
    rectMode(CORNER);
  }
}

//lets the buttons operate
function mouseClicked() {
  //sets areas on gameboxes that sends user into specified game
  if (screen == 0) {
    if (mouseY < 875 && mouseY > 725) {
      let gameX = 250;
      for (let i = 1; i < 4; i++) {
        if (mouseX < gameX + 275 && mouseX > gameX) {
          screen = i;
        }
        gameX += 400;
      }
    }

    //sends user to correct instruction menu
    if (mouseY < 1023 && mouseY > 900) {
      let instrX = 270;
      for (let i = 4; i < 7; i++) {
        if (mouseX < instrX + 275 && mouseX > instrX) {
          screen = i;
        }
        instrX += 400;
      }
    }
  }

  //home box, instruction box, game box, and youWin() menu code
  if (
    screen == 1 ||
    screen == 2 ||
    screen == 3 ||
    screen == 4 ||
    screen == 5 ||
    screen == 6
  ) {
    //home box button code to make it return to start screen
    if (mouseX < 250 && mouseX > 50) {
      if (mouseY < 150 && mouseY > 50) {
        screen = 0;
      }
    }

    //instructions box button code to send user to corresponding instruction screen
    if (mouseX < 480 && mouseX > 280) {
      if (mouseY < 150 && mouseY > 50) {
        if (screen == 1) {
          screen = 4;
        }
        if (screen == 2) {
          screen = 5;
        }
        if (screen == 3) {
          screen = 6;
        }
      }
    }

    //game box code to send user to the game of the intructions menu they're currently looking at
    if (mouseX < 250 && mouseX > 50) {
      if (mouseY < 270 && mouseY > 170) {
        if (screen == 4) {
          screen = 1;
        }
        if (screen == 5) {
          screen = 2;
        }
        if (screen == 6) {
          screen = 3;
        }
      }
    }

    //lets the youWin() function operate correctly
    if (winTrigger == true) {
      if (mouseY < 855 && mouseY > 680) {
        //home button
        if (mouseX < 730 && mouseX > 380) {
          screen = 0;
          winTrigger = false;
        }

        //reset button
        if (mouseX < 1230 && mouseX > 880) {
          resetGame();
          winTrigger = false;
        }
      }
    }
  }

  //Parts of soundTouchGame that require mouse clicks to work
  if (screen == 1) {
    //click on the big box to play the animal noise again
    if (mouseY < 500 && mouseY > 200) {
      if (mouseX < 1150 && mouseX > 400) {
        animalSoundArray[index].play();
      }
    }

    //top row of animals
    if (mouseY < 750 && mouseY > 600) {
      STBox(200, 0); //top left-most box
      STBox(450, 1); //top center-left box
      STBox(700, 2); //top center box
      STBox(950, 3); //top center-right box
      STBox(1200, 4); //top right-most box
    }

    //bottom row of animals
    if (mouseY < 1000 && mouseY > 850) {
      STBox(200, 5); //bottom left-most box
      STBox(450, 6); //bottom center-left box
      STBox(700, 7); //bottom center box
      STBox(950, 8); //bottom center-right box
      STBox(1200, 9); //bottom right-most box
    }
  }

  if (screen == 3) {
    //temporary timer stop button
    /*
    if ((mouseX < 600) && (mouseX > 500)) {
      if ((mouseY < 150) && (mouseY > 50)) {
        SMCounter++;    //easy reset button
        if (timerStart == false) {
          timerStart = true;
        }
        if (timerStart == true) {
          timerStart = false;
        }
      }
    }
    */

    //starts the game and the timer
    if (mouseX > 625 && mouseX < 975) {
      if (mouseY > 445 && mouseY < 595) {
        timerStart = true;
        startTrigger = true;
      }
    }
  }
}

function keyPressed() {
  if (screen == 2) {
    if (keyCode == ENTER) {
      doSomething(); //checks if word is correct when user presses enter key
    }
  }
}

function mousePressed() {
  //makes the game play the noise of the first animal when the sound touch game starts
  if (screen == 0) {
    if (mouseY < 875 && mouseY > 725) {
      if (mouseX < 525 && mouseX > 250) {
        animalSoundArray[index].play();
      }
    }
  }

  //makes the game play the noise of the first animal when the sound touch game starts
  if (screen == 4) {
    if (mouseY < 270 && mouseY > 170) {
      if (mouseX < 250 && mouseX > 50) {
        animalSoundArray[index].play();
      }
    }
  }

  if (screen == 3) {
    //calculates the distance between the mouse location and the middle of the moving shapes
    let cd = dist(mouseX, mouseY, circ1X, circ1Y);
    let rd = dist(mouseX, mouseY, rect1X, rect1Y);
    let sd = dist(mouseX, mouseY, sq1X, sq1Y);

    if (cd < circR) {
      circGrabbed = true; //grabs the circle if the mouse is over it
    } else if (rd < rectWidth - 150) {
      rectGrabbed = true; //grabs the rectangle if the mouse is over it
    } else if (sd < sqD - 68) {
      sqGrabbed = true; //grabs the square if the mouse is over it
    } else {
      rectGrabbed = false;
      sqGrabbed = false;
      circGrabbed = false;
    }
  }
}

function mouseDragged() {
  if (screen == 3) {
    //allows user to move the shapes
    if (circGrabbed) {
      circ1X = mouseX;
      circ1Y = mouseY;
    }
    if (rectGrabbed) {
      rect1X = mouseX;
      rect1Y = mouseY;
    }
    if (sqGrabbed) {
      sq1X = mouseX;
      sq1Y = mouseY;
    }
    //makes it so user can't move shapes after winning
    if (winTrigger == true) {
      circGrabbed = false;
      rectGrabbed = false;
      sqGrabbed = false;
    }
  }
}

function mouseReleased() {
  //releases the shapes
  if (screen == 3) {
    circGrabbed = false;
    rectGrabbed = false;
    sqGrabbed = false;
  }
}
